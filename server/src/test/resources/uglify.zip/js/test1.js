(function() {
	alert('Test1');
})()
