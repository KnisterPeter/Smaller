(function() {
	var aLongVariableName = "Test 2";
	alert(aLongVariableName);
})();
